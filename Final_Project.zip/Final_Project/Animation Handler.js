document.addEventListener("DOMContentLoaded", () => {
    const character = document.getElementById("character");
    const jeep = document.getElementById("jeep");

    // Animation states
    const characterAnimations = [
        "Final project/Assests/man/walking_sheet.png",
        "Final project/Assests/man/running_sheet.png",
        "Final project/Assests/man/jumping_sheet.png"
    ];

    const jeepAnimations = [
        "Final project/Assests/Jeep/Idle.png",
        "Final project/Assests/Jeep/Ride.png",
        "Final project/Assests/Jeep/Brake.png"
    ];

    let currentAnimation = 0;

    document.addEventListener("click", () => {
        // Change animation frame
        currentAnimation = (currentAnimation + 1) % characterAnimations.length;

        // Apply new animations
        character.style.backgroundImage = `url('${characterAnimations[currentAnimation]}')`;
        jeep.style.backgroundImage = `url('${jeepAnimations[currentAnimation]}')`;
    });
});
